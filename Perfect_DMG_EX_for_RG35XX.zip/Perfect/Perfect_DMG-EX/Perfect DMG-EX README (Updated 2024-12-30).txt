Perfect DMG-EX and GBP-EX Overlays for Garlic OS

Updated 2024-12-30:
- fixed minor visual artifact in some GBP overlays

Updated 2024-10-04:
- added improved DMG and GBP bezel shadows
- added no grid, no shadow, etc options for all borders
- restructured folders to make the choices less overwhelming/difficult to navigate

**DO NOT USE THESE OVERLAYS WITH THE MIYOO MINI (PLUS)**

These files are adapted for Garlic OS on the original RG35XX from u/1playerinsertcoin's Perfect DMG-EX and GBP-EX overlays for the Miyoo Mini Plus (https://www.reddit.com/r/MiyooMini/comments/18e2o0z/i_remastered_my_game_boy_dmg_overlay/). All credit goes to them - my only contributions are minor fixes and the borders on the _mugwomp93 overlays.

Due to minor differences in the video output of the Miyoo Mini Plus and the RG35XX, the grid needed to be shifted two pixels horizontally in order to properly align with the RG35XX GB output. Please refer to the original post for files and settings for the MM+, including Onion OS color correction settings not included here.

Note that these overlays have been tested on the original RG35XX with Garlic 1.4.9 and there are known alignment problems with other devices (MM+, RG35XX Plus/H/SP/2024). Files for the RG35XX Plus/H/SP/2024 (and likely other non-Miyoo Mini 640x480 devices) are on my other Github repository (https://github.com/mugwomp93/muOS_Customization).

******

I've included conversions of the original Perfect DMG-EX and GBP-EX overlays as well as ones with my own borders. 1playerinsertcoin also created custom DMG and GBP palettes for these overlays; the two are meant to work together so the overlays may not look right without the custom palettes (and vice versa).

Copy the palettes folder from either the DMG or GBP folder into your BIOS folder (BIOS folder on TF2 if using two SD cards). Then set GB Colorization to Custom in Core Options as per the settings below. Make sure you use the appropriate corresponding overlay for your palette file (i.e., DMG or GBP), otherwise the output will look strange. The default Retroarch file name for custom palettes is default.pal - I don't believe it can be changed or selected from a list, so you can only use one custom palette (i.e., copying both over will overwrite whichever one is copied first). You could, of course, rename the files to keep them together, but you'll need to rename them again if you want to switch custom palettes in the future.


To apply the overlay and recommended settings:

1. Quick Menu > On-Screen Overlay

   Display Overlay > ON

   Overlay Preset...
     - Navigate to the main Overlays folder: /CFW/retroarch/.retroarch/overlay
     - Perfect > Perfect_DMG-EX > DMG or GBP (depending on which you want to use)
     - Select your preferred overlay:
          - _noframe indicates just the grid with no logos, shadows, etc.
          - _noshadow indicates no border shadows
          - _nogrid indicates just the borders +/- shadow with no grid
          - the other variations are simply different border decorations


2. Quick Menu > Core Options:

    GB Colorization > Custom

    Interframe Blending	> Simple (NOTE: If you don't like the image ghosting, turn it OFF, but you may see flickering elements in games.)

    Manage Core Options > Save Content Directory Options


3a. Main Menu (press B to back out of Quick Menu) > Settings > Video

    Image Interpolation > Bilinear4X


3b. Main Menu > Settings > Video > Scaling    

    Integer Scale > OFF

    Keep Aspect Ratio > ON


4. Once you've got everything configured the way you want it, save your settings:

   Quick Menu > Overrides > Save Content Directory Overrides


Note that these are BRIGHT overlays. You'll need to reduce the screen brightness to get them to look right (menu + volume down in Garlic OS).

There's a lot of interesting discussion in the comments of the Reddit post - I highly recommend reading through them if you're interested in the technical details and process that were used to create these overlays.

-mugwomp93