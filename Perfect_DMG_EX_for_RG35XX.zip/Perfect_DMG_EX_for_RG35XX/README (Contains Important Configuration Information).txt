Perfect DMG-EX and GBP-EX Overlays for the RG35XX

**DO NOT USE THESE OVERLAYS WITH THE MIYOO MINI (PLUS)**

These files are adapted for the RG35XX from u/1playerinsertcoin's Perfect DMG-EX and GBP-EX overlays for the Miyoo Mini Plus (https://www.reddit.com/r/MiyooMini/comments/18e2o0z/i_remastered_my_game_boy_dmg_overlay/). All credit goes to them - my only contributions are minor fixes and the borders on the _mugwomp93 overlays.

Due to minor differences in the video output of the Miyoo Mini Plus and the RG35XX, the grid needed to be shifted two pixels horizontally in order to properly align with the RG35XX GB output. Please refer to the original post for files and settings for the MM+.

******

I've included conversions of the original Perfect DMG-EX and GBP-EX overlays as well as ones with my own borders. 1playerinsertcoin also created custom DMG and GBP palettes for these overlays; the two are meant to work together so the overlays may not look right without the custom palettes (and vice versa).

Copy the palettes folder from either the DMG or GBP folder into your BIOS folder (BIOS folder on TF2 if using two SD cards). Then set GB Colorization to Custom in Core Options as per the settings below. Make sure you use the appropriate corresponding overlay for your palette file (i.e., DMG or GBP), otherwise the output will look strange. The default Retroarch file name for custom palettes is default.pal - I don't believe it can be changed or selected from a list, so you can only use one custom palette (i.e., copying both over will overwrite whichever one is copied first). You could, of course, rename the files to keep them together, but you'll need to rename them again if you want to switch custom palettes in the future.

1playerinsertcoin's recommended Retroarch settings (from the first comment on the Reddit post) are:

1. Core Options:

    GB Colorization > Custom
    Interframe Blending > Simple (Note: Don't use any of the "LCD Ghosting" presets as they produce additional graphical artifacts in dark areas)


2. Video Settings:

    Integer Scale OFF

    Keep Aspect Ratio ON

    Image Interpolation > Bicubic (RG35XX does not have Bicubic interpolation. I use Bilinear 4X instead.)

Note that these are BRIGHT overlays. You'll need to reduce the screen brightness to get them to look right (menu + volume down in Garlic 1.4.9).

There's a lot of interesting discussion in the comments of the Reddit post - I highly recommend reading through them if you're interested in the technical details and process that were used to create these overlays.

-mugwomp93