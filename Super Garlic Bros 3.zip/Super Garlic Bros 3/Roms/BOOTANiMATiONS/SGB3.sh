#!/bin/sh
msg="/mnt/mmc/Roms/BOOTANIMATIONS/BootAnimsPrint"

$msg/printstr "    Switching boot animation...    " & sleep 1
mount -o remount,rw /misc

# Check if /misc/dmenu.bin includes "/mnt/mmc/BootAnimations/start.sh" line
if ! grep -q "/mnt/mmc/BootAnimations/start.sh" /misc/dmenu.bin; then
    # Check if /misc/dmenu.bin includes "# Create the TF2 directory structure" line
    if grep -q "# Create the TF2 directory structure" /misc/dmenu.bin; then
        # Insert "/mnt/mmc/BootAnimations/start.sh" before the line in /misc/dmenu.bin
        sed -i '/# Create the TF2 directory structure/i /mnt/mmc/BootAnimations/start.sh' /misc/dmenu.bin
    fi
fi

mount -o remount,ro /misc

# Modify /mnt/mmc/BootAnimations/start.sh to replace the theme path
sed -i 's|THM=$DIR/theme/.*|THM=$DIR/theme/SGB3|' /mnt/mmc/BootAnimations/start.sh

	$msg/printstr "Super Garlic Bros. 3"
	sleep 2

echo 50 > "/sys/class/power_supply/battery/moto"
busybox sleep 0.2
echo 0 > "/sys/class/power_supply/battery/moto"

	$msg/printstr "System will reboot in.."
	sleep 1
	$msg/printstr "     3     "
	sleep 0.5
	$msg/printstr "     2     "
	sleep 0.5
	$msg/printstr "     1     "
	sleep 0.5
	reboot -f
