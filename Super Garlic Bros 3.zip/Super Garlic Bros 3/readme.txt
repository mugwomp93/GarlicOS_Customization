Super Garlic Bros. 3 Boot Animation
by mugwomp93

For use with RetroMateo's Boot Animation Switcher (which is based on Adixal's Animated Bot Logo mod). The Boot Animation Switcher App is available at RG35xx.com: https://www.rg35xx.com/en/apps/apps-for-garlicos/

I've also included a boot logo of the SMB3 curtain to integrate the static boot logo into the animation.

Enjoy!