Perfect GBC Overlays for Garlic OS

Updated 2024-10-04:
- added new border options (including one based on one of 1playerinsertcoin's original designs!)
- added no grid, no shadow, etc options for all borders
- restructured folders to make the choices less overwhelming/difficult to navigate

**DO NOT USE THESE OVERLAYS WITH THE MIYOO MINI (PLUS)**

These files are adapted for Garlic OS on the original RG35XX from u/1playerinsertcoin's Perfect GBC overlay for the Miyoo Mini Plus (https://www.reddit.com/r/MiyooMini/comments/1857xa7/i_made_a_game_boy_color_overlay/). All credit goes to them - my only contributions are minor fixes and the borders on the _mugwomp93 overlays.

Due to minor differences in the video output of the Miyoo Mini Plus and the RG35XX, the grid needed to be shifted two pixels horizontally in order to properly align with the RG35XX GBC output. Please refer to the original post for files and settings for the MM+, including Onion OS color correction settings not included here.

Note that these overlays have been tested on the original RG35XX with Garlic 1.4.9 and there are known alignment problems with other devices (MM+, RG35XX Plus/H/SP/2024). Files for the RG35XX Plus/H/SP/2024 (and likely other non-Miyoo Mini 640x480 devices) are on my other Github repository (https://github.com/mugwomp93/muOS_Customization).

******

I've included conversions of the original Perfect GBC overlays as well as one with my own borders. If you find the overlay is too dark at maximum brightness, you could customize it by adjusting the opacity of the _noframe variant and then applying the _nogrid (i.e., borders and shadow only) variant over top in Photoshop, GIMP, etc. Note, however, that this comes at the expense of accuracy.

To apply the overlay and recommended settings:

1. Quick Menu > On-Screen Overlay

   Display Overlay > ON

   Overlay Preset...
     Navigate to the main Overlays folder: /CFW/retroarch/.retroarch/overlay
     - Perfect > Perfect_GBC
     - Select your preferred overlay:
          - _noframe indicates just the grid with no logos, shadows, etc.
          - _noshadow indicates no border shadows
          - _nogrid indicates just the borders +/- shadow with no grid
          - the other variations are simply different border decorations


2. Quick Menu > Core Options:

    GB Colorization > GBC

    Color Correction > GBC Only

    Color Correction Mode > Accurate

    Color Correction - Frontlight Position > Above Screen (lighter, for more realistic GBC colors) or Central (darker, for more vibrant colors and inky blacks)

    Interframe Blending > Simple  (NOTE: If you don't like the image ghosting, turn it OFF, but you may see flickering elements in games.)

    Manage Core Options > Save Content Directory Options


3a. Main Menu (press B to back out of Quick Menu) > Settings > Video

    Image Interpolation > Bilinear4X


3b. Main Menu > Settings > Video > Scaling    

    Integer Scale > OFF

    Keep Aspect Ratio > ON


4. Once you've got everything configured the way you want it, save your settings:

   Quick Menu > Overrides > Save Content Directory Overrides


***Note that these are DARK overlays. You'll need to increase the screen brightness to maximum (or fairly close) to get them to look right (menu + volume up in Garlic OS).***

There's a lot of interesting further discussion in the comments of the Reddit post - I highly recommend reading through them if you're interested in the technical details and process that were used to mimic the GBC display.

-mugwomp93