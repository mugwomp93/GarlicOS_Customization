Perfect GBA Overlays for Garlic OS

Updated 2024-10-04:
- added slightly improved border shadows (darker corners so bright colors show through less)
- made the narrow gray bar at the top of the _mugwomp93 border darker
- added new border options
- added no grid, no shadow, etc options for all borders
- bundled centered versions in the main Perfect GBA zip file in addition to the separate file
- replaced the 424p grid previously used in the centered version with the original 427p grid
- restructured folders to make the choices less overwhelming/difficult to navigate

**DO NOT USE THESE OVERLAYS WITH THE MIYOO MINI (PLUS)**

These files are adapted for Garlic OS on the original RG35XX  from u/1playerinsertcoin's Perfect GBA overlay for the Miyoo Mini Plus (https://www.reddit.com/r/MiyooMini/comments/18ovuld/i_made_a_game_boy_advance_overlay/?rdt=52022). All credit goes to them - my only contributions are minor fixes and the borders on the _mugwomp93 overlays. 

Due to differences in the video output of the Miyoo Mini Plus and the RG35XX, the bottom border needed to be three pixels taller to properly align with the RG35XX GBA output when offset (i.e., 424p instead of 427p). Please refer to the original post for files and settings for the MM+, including Onion OS color correction settings not included here.

This zip file includes centered versions of the Perfect GBA overlays in addition to the offset versions. Please see the Centered_Version subfolder for instructions and recommended settings for those versions.

Note that these overlays have been tested on the original RG35XX with Garlic 1.4.9 and there are likely alignment problems on other devices due to the 424p vertical resolution. Files for the RG35XX Plus/H/SP/2024 (and likely other non-Miyoo Mini 640x480 devices) are on my other Github repository (https://github.com/mugwomp93/muOS_Customization).

******

Thank you very much to 1playerinsertcoin for generating 424p grids specifically for Garlic OS! Using the original grid for the MM+ introduced a few annoying (albeit minor) artifacts that are not present using the new grid.

The zip includes both the optimized and bright versions of the Perfect GBA grid. The grid of the bright version isn't quite as dark as the optimized version, though this comes at the expense of accuracy. If you find the bright version is still too dark, you could customize the overlay by adjusting the opacity of one of the _noframe variants and then applying your preferred version of the _nogrid (i.e., borders and shadow only) variants over top in Photoshop, GIMP, etc.

To apply the overlay (offset version only) and recommended settings:

1. Quick Menu > On-Screen Overlay

   Display Overlay > ON

   Overlay Preset...
     Navigate to the main Overlays folder: /CFW/retroarch/.retroarch/overlay
     - Perfect > Perfect_GBA
     - Select your preferred overlay:
          - _noframe indicates just the grid with no logos, shadows, etc.
          - _noshadow indicates no border shadows
          - _nogrid indicates just the borders +/- shadow with no grid
          - the other variations are simply different border decorations


2. Quick Menu > Core Options:

    Video > Color Correction > OFF

    Video > Interframe Blending > Simple (NOTE: If you don't like the image ghosting, turn it OFF, but you may see flickering elements in games.)

    Manage Core Options > Save Content Directory Options


3a. Main Menu (press B to back out of Quick Menu) > Settings > Video

    Image Interpolation > Bilinear4X 

    Video Filter > Normal4X.filt


3b. Main Menu > Settings > Video > Scaling

    Integer Scale > OFF

    Keep Aspect Ratio > ON


4. Once you've got everything configured the way you want it, save your settings:

   Quick Menu > Overrides > Save Content Directory Overrides


***Note that these are DARK overlays. You'll need to increase the screen brightness to maximum (or fairly close) to get them to look right (menu + volume up in Garlic OS).***

There's a lot of interesting discussion in the comments of the Reddit post - I highly recommend reading through them if you're interested in the technical details and process that were used to create these overlays.

-mugwomp93