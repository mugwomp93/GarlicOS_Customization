Perfect Overlays for Garlic OS Bundle

**DO NOT USE THESE OVERLAYS WITH THE MIYOO MINI (PLUS)**

Updated 2024-10-04:
- added improved DMG, GBP, and GBA bezel shadows
- added more border designs
- added no grid, no shadow, etc options for all borders
- restructured folders to make the choices less overwhelming/difficult to navigate
- updated readme files for the individual systems

*****

This is a collection of 1playerinsertcoin's Perfect overlays for GB (DMG and GBP), GBC, and GBA adapted and bundled with instructions for Garlic OS on the original RG35XX. I've made some minor edits to the original MM overlays for alignment and have added options with my own borders, but the grids and magic are all theirs. You can check out all of their overlays, including other overlays that don't need to be adapted (e.g., CRT, Game Gear) on their Reddit profile:

https://www.reddit.com/user/1playerinsertcoin/submitted/

For the Miyoo Mini and Miyoo Mini Plus:
Please refer to 1playerinsertcoin's profile linked above. Some versions of these overlays are also included in Onion OS.

For the RG35XX Plus/H/SP/2024:
Please use the overlays included in my other Github repository. The overlays included in this zip file are not properly sized and/or aligned for these devices.

https://github.com/mugwomp93/muOS_Customization

For other 640x480 devices:
The repository linked above is likely your best bet, but ymmv given that all three devices tested (MM, OG RG35XX, RG35XX Plus) had minor alignment differences. The linked set is likely the bet place to start, though, as it has the most neutral/expected grid resolutions based on scaling calculations and all of the grids are centered horizontally.


To use these overlays:

     1. Copy the "Perfect" folder to:

        /CFW/retroarch/.retroarch/overlay

     2. See the README files in the relevant subfolders (Perfect_DMG-EX, Perfect_GBC, Perfect_GBA) for system-specific settings

- mugwomp93