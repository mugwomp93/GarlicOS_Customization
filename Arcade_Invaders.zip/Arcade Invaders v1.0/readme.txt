Arcade Invaders theme by mugwomp93

This is my personal theme that I'm tinkering with on an ongoing basis. I will update with any significant improvements. My goal is to eventually make the top and bottom bars resemble an arcade cabinet bezel + controls.

Pleae note that this theme hasn't been optimized for any language other than English as it's a work in progress. 