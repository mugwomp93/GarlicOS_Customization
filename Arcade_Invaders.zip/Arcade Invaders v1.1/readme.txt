Arcade Invaders theme by mugwomp93

This is my personal theme that I'm tinkering with on an ongoing basis. I will update with any significant improvements.

Version 1.1 Update 2024-04-23: Updated bezels with a better perspective effect, replaced navigation icon with triangular arcade buttons.

Pleae note that this theme hasn't been optimized for any language other than English.