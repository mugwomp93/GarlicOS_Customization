Adapted from Kitsuvi's GBOnion theme for Onion OS.
Thanks to u/denizoart (denizonm) for help with links, suggestions, and discussion.

Note that the configuration for the Japanese, Simplified Chinese, and Traditional Chinese localizations is sub-optimal (i.e., there's a gray dot in the middle of each of the main icons). I tried to adapt the SC and TC fonts the same way as I did the others but attempting to use the modified fonts crashed Garlic to a black screen. Would be happy to hear if anyone has ideas to troubleshoot, as my attempts were (obviously) unsuccessful.

- mugwomp93 (u/mugwomp_93)
