Perfect GBC Overlays for the RG35XX

**DO NOT USE THESE OVERLAYS WITH THE MIYOO MINI (PLUS)**

These files are adapted for the RG35XX from u/1playerinsertcoin's Perfect GBC overlay for the Miyoo Mini Plus (https://www.reddit.com/r/MiyooMini/comments/1857xa7/i_made_a_game_boy_color_overlay/). All credit goes to them - my only contributions are minor fixes and the borders on the _mugwomp93 overlays.

Due to minor differences in the video output of the Miyoo Mini Plus and the RG35XX, the grid needed to be shifted two pixels horizontally in order to properly align with the RG35XX GBC output. Please refer to the original post for files and settings for the MM+.

******

I've included conversions of the original Perfect GBC overlays as well as one with my own borders. I've also included versions with the grid opacity reduced to 70% and 50% of the original, though I recommend using the original files and increasing the screen brightness to get the full effect as intended.

1playerinsertcoin's recommended Retroarch settings (from the first comment on the Reddit post) are:

1. Core Options:

    GB Colorization > GBC

    Color Correction > GBC Only

    Color Correction Mode > Accurate

    Color Correction - Frontlight Position > Above Screen (lighter, for more realistic GBC colors) or Central (darker, for more vibrant colors and inky blacks)

    Interframe Blending > Simple

2. Video Settings:

    Integer Scale OFF

    Keep Aspect Ratio ON

    Image Interpolation > Bicubic (RG35XX does not have Bicubic interpolation. I use Bilinear 4X instead.)

There's a lot of interesting further discussion in the comments of the Reddit post - I highly recommend reading through them if you're interested in the technical details and process that were used to mimic the GBC display.

FYI, I'm also in the process of adapting 1playerinsertcoin's other overlays (DMG, GBP, GBA) for the RG35XX. I plan to post all of the overlays to Reddit once I've finished adapting the GBA overlay.

-mugwomp93