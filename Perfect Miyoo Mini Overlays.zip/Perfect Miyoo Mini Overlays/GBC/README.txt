Recommended Retroarch settings are:

1. Core Options:

    GB Colorization > GBC

    Color Correction > GBC Only

    Color Correction Mode > Accurate

    Color Correction - Frontlight Position > Above Screen (lighter, for more realistic GBC colors) or Central (darker, for more vibrant colors and inky blacks)

    Interframe Blending > Simple

2. Video Settings:

    Integer Scale OFF

    Keep Aspect Ratio ON

    Image Interpolation > Bicubic

Thank you to u/1playerinsertcoin and u/mugwomp_93 on Reddit!