Inspired by, and heavily based on, huor_fashmir's cute and cozy charging animation for the Miyoo Mini: https://www.reddit.com/r/MiyooMini/comments/1b19k49/i_made_this_cute_and_simple_chrono_trigger/

I originally just intended to port it over, but there were enough minor edits and different screens required that I decided to recreate it (with some minor changes for personal preference) instead.

Uses Adixal's charging animation mod for Garlic OS 1.4.9 (as hosted on RG35XX.com: https://www.rg35xx.com/en/apps/mods-for-garlicos/)

Enjoy!

- mugwomp93


GarlicOs Battery Charging Animation Instructions
By: Adixal

Replace the supplied "ramdisk.img" file in the Misc partition with the supplied one.
Copy the "battery" folder to the Misc partition. (You can modify these images to your liking)

Enjoy your new battery charging animation.