Perfect GBA Overlays for the RG35XX

**DO NOT USE THESE OVERLAYS WITH THE MIYOO MINI (PLUS)**

These files are adapted for the RG35XX from u/1playerinsertcoin's Perfect GBA overlay for the Miyoo Mini Plus (https://www.reddit.com/r/MiyooMini/comments/18ovuld/i_made_a_game_boy_advance_overlay/?rdt=52022). All credit goes to them - my only contributions are minor fixes and the borders on the _mugwomp93 overlays.

Due to differences in the video output of the Miyoo Mini Plus and the RG35XX, the bottom border needed to be three pixels taller or the grid centered (i.e., not offset) in order to properly align with the RG35XX GBA output. Please refer to the original post for files and settings for the MM+.

Note that these overlays have been tested on the original RG35XX with Garlic 1.4.9. I have no idea how they look on the Plus, H, or with different firmware.

******

Unfortunately, there was no easy way to align the output with this overlay. The vertical video output when offset is three pixels shorter than it should be, and I was unable to find an alternative GBA offset filter that yields the proper vertical resolution on the RG35XX. Since the difference is small (<1%) it's not really fixable, and there are some minor artifacts and misalignments that, knowing 1playerinsertcoin's high standards, I'm confident are not present on the MM+. I don't really notice the artifacts when playing, only when a game is paused, though they might be more noticeable when playing Pokemon or other games where you spend a lot of time in static screens. I still think it's far superior to the Grid3X filter, which is the only other offset filter I found to work on the RG35XX.

In an attempt to better align the grid, I made a second, centered version of the overlay. While the vertical GBA output when using an offset filter is always three pixel shorter than it should be, the height of the video output when centered varies depending on the interpolation method used. I found that only Bilinear2X yielded the correct image size. I've included the alignment overlays I used to check the image size for anyone who's interested - the white bars represent the correct border height(s) and the pink and blue are just individual pixel increments so I could get an idea of how much the image size varied. There are still some vertical alignment artifacts that I'm guessing are due to differences between Bilinear2X and Bicubic interpolation (which is recommended for the MM+ and not available in Garlic 1.4.9), but it's an improvement over the offset version. I still use the offset version because I find the improvement to be minimal and I prefer the look.

The recommended Retroarch settings (adapted from the first comment on the Reddit post) are:

1. Core Options:

    Video > Color Correction > OFF

    Video > Interframe Blending > Simple (NOTE: If you don't like the image ghosting, turn it OFF, but you may see flickering elements in games.)


2. Video Settings:

    Integer Scale OFF

    Keep Aspect Ratio ON

 a. For the offset overlays:

    Image Interpolation > Bilinear4X (RG35XX does not have Bicubic interpolation)

    Video Filter > Normal4X.filt (GBA > Filter for overlays > GBAOffset.filt does not work on the RG35XX)

 b. For the centered overlays:    
    
    Image Interpolation > Bilinear2X (RG35XX does not have Bicubic interpolation)

    Video Filter > none


There's a lot of interesting discussion in the comments of the Reddit post - I highly recommend reading through them if you're interested in the technical details and process that were used to create these overlays.

-mugwomp93