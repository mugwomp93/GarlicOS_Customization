( )------{===================================================>

                   MOVING DUNGEON by mugwomp93

( )------{===================================================>

- This theme is a modification of 420AM's wonderfully nostalgic Minimal Dungeon theme. The boot logo is mine, but the vast majority of assets used in the theme are theirs (other than the wizard graphic, which is from the Apple II version of Wizardry: Proving Grounds of the Mad Overlord). I also stole their readme sword banner because it's great. 
- The original README notes from Minimal Dungeon follow my notes. In particular, there are instructions for formatting game artwork and aligning text to account for the menu elements in this theme, as well as attributions for the various assets used.

1. COMPATIBILITY: tested on Garlic OS 1.3.2

2. INSTALLATION
- On partition containing 'CFW' folder, copy the 'CFW' folder
- On partition containing 'boot_logo.bmp.gz', replace boot_logo.bmp.gz for a Wizardry style boot logo. I've also retained 420AM's original boot logo (boot_logo_old.bmp.gz) if you prefer.

3. NOTES
- Language compatibility is broken for the main icons since it's otherwise impossible to center the labels. If you do want to localize this theme, the labels were created using the same ChiKareGo font that is included in the font folder. The color is #00d8d8. The text portions of the icons are over transparency, so the images should be easy to edit.
- In order to remove the main icon labels, I deleted the @ character from the font (font_mod.ttf) using FontForge and renamed the applicable labels in settings.json and English.json to "@". The original, unedited font is also included in the font folder (font.ttf) if you choose to edit the icons and would prefer not to install the modified font.
- As indicated in 420AM's notes below, the clock and language settings screen originally rendered black text over a black background. I've changed the "color-guide" parameter in settings.json from #000000 to #555555 so the text is now visible (dark gray); however, the navigation button text and the text at the top of the screen are now also dark gray. I don't find it terrible, though I will probably revert to black for my own use. You can change the text back to black by changing the color-guide value back to #000000.

4. THEME DEVELOPMENT NOTES
- Full-screen active icon sizes are:
	Recent: 	 640x480
	Favorites: 	 640x480
	Consoles: 	 800x480 (only left 640x480 shown)
	Retroarch: 	2720x480 (only left 640x480 shown)

- The padding areas of the Consoles and Retroarch are colored bright pink, so you could just overwrite my icons if you want to use the same effect in your theme and don't want to troubleshoot icon sizes or positioning (e.g., for smaller icons).

5. LONG-WINDED THEME DEVELOPMENT NOTES
- I undertook this theme as an exercise to see whether I could manipulate the icon images to "change" the background beyond the 160 px section of the screen (i.e., 1/4) allocated to each icon. As this theme exists, it's possible, but there are some oddities as to how the images are rendered.
- For the most part, Garlic will attempt to center the icon in its quarter of the screen. The left edge of the screen seems to be a "hard" edge, in that icons are shifted right if the would otherwise overlap the edge. For example, the Recent and Favorites icons included in this theme are 640x480, but the entirety of each image is shown on the screen when active. When I originally made these icons they were smaller and the positioning was odd due to the interaction between icon width, centering, and the hard left edge.
- The positioning of the Consoles and Retroarch icons (especially the Retroarch icon) is peculiar. The Consoles icon seems to center in its quadrant, which requires extra padding on the right side of the icon to center the image on the screen (i.e., the icon is 800x480, but only the left 640x480 is shown). However, the positioning of this icon also seems to be influenced by the width of the fourth icon. This isn't apparent given the massive size of the Retroarch icon (next point) and the hard left edge, but in early iterations the positioning of this icon changed based solely on changes to the width of the Retroarch icon.
- The positioning of the Retroarch icon is affected by its width and the combined widths of the other active icons; however, it doesn't seem to try to center in its quadrant when the other icons are as large as they are. In order to position the image properly, I had to add a ridiculous amount of padding, such that the icon is 2720x480. As with the Consoles icon, only the left 640x480 is shown. 
- The sizes of the inactive icons didn't affect the placement of the active icons (I tested using both 160 px and 2 px icons), but I don't know what happens when the inactive icons are >160 px or how they render relative to the active icons since this theme only uses blank images for the inactives.

##### ORIGINAL README #####

( )------{===================================================>

                   MINIMAL DUNGEON by 420AM

( )------{===================================================>

COMPATIBILITY: tested on Garlic OS 1.3.2

# INSTALLATION
- On partition containing 'CFW' folder, copy the 'CFW' folder
- On partition containing 'boot_logo.bmp', replace boot_logo.bmp for 1-bit style Anbernic original bootlogo

## IMAGE FORMATTING
- To format images to match this skin as intended (this will resize images onto left side, centered, and account for ~6px padding around the menu elements):
- Install ImageMagick: https://imagemagick.org/script/download.php
- Right click on your images folder, select 'Open powershell window here' then run the first script, followed by the second
- magick mogrify -resize "314x332" -gravity center -extent 314x332 -background transparent -flatten *
- magick mogrify -background transparent -gravity west -extent 634x454 -gravity west -splice 6x0 -gravity south -splice 0x26 *

### IF NO IMAGE FORMATTING
- Open 'settings.json' located in the 'skin' folder
- Modify the following 2 lines to match:
- "text-alignment": "center",
- "text-margin": 16,
- This will re-align the text back to center like the default skin

#### NOTES

- Unfortunately, I noticed a flaw in this skin, when hitting start to change the time/date/language this skin will produce black text on top of a mostly black background. If anyone knows a solution hit me up.
- I only have the english.json settings file to accomodate the font set at this time, if anyone is adapting for another language please send it my way and I will include in the official repository

##### ACKNOWLEDGEMENTS
- This skin was originally based off Platinum by Jason Scheirer (https://github.com/jasonbot/platinum-garlic)
- Font is [ChiKareGo](http://www.pentacom.jp/pentacom/bitfontmaker2/gallery/?id=3778)
- System logos are from [Express Mode](https://www.rg35xx.com/temas-garlicos/) and friends on [www.rg35xx.com](https://www.rg35xx.com/)
- Button icons are modified from [ansdor](https://ansdor.itch.io/button-icons)

( )------{===================================================>