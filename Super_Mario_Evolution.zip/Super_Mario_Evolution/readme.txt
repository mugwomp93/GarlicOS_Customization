Please note that I've only provided an English localization because the main menu and navigation guide labels were made using the appropriate SMB1/2/3 and SMW letter sprites and are embedded in the graphics. If you would like to have this theme localized for another language, please feel free to contact me on Reddit (u/mugwomp_93). Languages that use Latin/Roman script should be simple enough to localize; for others I may need assistance in locating suitable substitute fonts as neither the sprite sheets nor the SuperMario-286 font include non-Latin characters.

- mugwomp93
